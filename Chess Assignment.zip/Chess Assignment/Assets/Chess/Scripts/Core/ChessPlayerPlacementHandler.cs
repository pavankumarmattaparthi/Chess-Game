﻿using System;
using UnityEngine;

namespace Chess.Scripts.Core {
    public class ChessPlayerPlacementHandler : MonoBehaviour {
        [SerializeField] public int row, column;
        public ChessBoardPlacementHandler ChessBoardPlacementHandler;
        public bool Selected, pawnFirstMove;
        public GameObject window;
        public Sprite[] newSprite = new Sprite[0];
        public bool white;

        private void Start() {
            transform.position = ChessBoardPlacementHandler.Instance.GetTile(row, column).transform.position;
            //note the position of chess pieces
            ChessBoardPlacementHandler.KeyValue(row, column, true, white); 
        }

        void Update()
        {
            //Access to change the position of chess pieces 
            if (Input.GetMouseButtonDown(0))
            {
                Vector2 origin = new Vector2(Camera.main.ScreenToWorldPoint(Input.mousePosition).x, Camera.main.ScreenToWorldPoint(Input.mousePosition).y);
                RaycastHit2D hit = Physics2D.Raycast(origin, Vector2.zero, 0f);
                if (hit)
                {
                    if (hit.transform.name != "Highlighter(Clone)" && hit.transform.name != this.name)
                        Selected = false;
                    if (hit.transform.name == "Highlighter(Clone)" && Selected)
                    {
                        GameObject obj = hit.transform.parent.gameObject;
                        ChessBoardPlacementHandler.KeyValueFalse(row, column);
                        string tagname = obj.transform.name;
                        switch (tagname)
                        {
                            case "0":
                                ChangeKeyPosition(0, 0);
                                break;
                            case "1":
                                ChangeKeyPosition(0, 1);
                                break;
                            case "2":
                                ChangeKeyPosition(0, 2);
                                break;
                            case "3":
                                ChangeKeyPosition(0, 3);
                                break;
                            case "4":
                                ChangeKeyPosition(0, 4);
                                break;
                            case "5":
                                ChangeKeyPosition(0, 5);
                                break;
                            case "6":
                                ChangeKeyPosition(0, 6);
                                break;
                            case "7":
                                ChangeKeyPosition(0, 7);
                                break;
                            case "8":
                                ChangeKeyPosition(1, 0);
                                break;
                            case "9":
                                ChangeKeyPosition(1, 1);
                                break;
                            case "10":
                                ChangeKeyPosition(1, 2);
                                break;
                            case "11":
                                ChangeKeyPosition(1, 3);
                                break;
                            case "12":
                                ChangeKeyPosition(1, 4);
                                break;
                            case "13":
                                ChangeKeyPosition(1, 5);
                                break;
                            case "14":
                                ChangeKeyPosition(1, 6);
                                break;
                            case "15":
                                ChangeKeyPosition(1, 7);
                                break;
                            case "16":
                                ChangeKeyPosition(2, 0);
                                break;
                            case "17":
                                ChangeKeyPosition(2, 1);
                                break;
                            case "18":
                                ChangeKeyPosition(2, 2);
                                break;
                            case "19":
                                ChangeKeyPosition(2, 3);
                                break;
                            case "20":
                                ChangeKeyPosition(2, 4);
                                break;
                            case "21":
                                ChangeKeyPosition(2, 5);
                                break;
                            case "22":
                                ChangeKeyPosition(2, 6);
                                break;
                            case "23":
                                ChangeKeyPosition(2, 7);
                                break;
                            case "24":
                                ChangeKeyPosition(3, 0);
                                break;
                            case "25":
                                ChangeKeyPosition(3, 1);
                                break;
                            case "26":
                                ChangeKeyPosition(3, 2);
                                break;
                            case "27":
                                ChangeKeyPosition(3, 3);
                                break;
                            case "28":
                                ChangeKeyPosition(3, 4);
                                break;
                            case "29":
                                ChangeKeyPosition(3, 5);
                                break;
                            case "30":
                                ChangeKeyPosition(3, 6);
                                break;
                            case "31":
                                ChangeKeyPosition(3, 7);
                                break;
                            case "32":
                                ChangeKeyPosition(4, 0);
                                break;
                            case "33":
                                ChangeKeyPosition(4, 1);
                                break;
                            case "34":
                                ChangeKeyPosition(4, 2);
                                break;
                            case "35":
                                ChangeKeyPosition(4, 3);
                                break;
                            case "36":
                                ChangeKeyPosition(4, 4);
                                break;
                            case "37":
                                ChangeKeyPosition(4, 5);
                                break;
                            case "38":
                                ChangeKeyPosition(4, 6);
                                break;
                            case "39":
                                ChangeKeyPosition(4, 7);
                                break;
                            case "40":
                                ChangeKeyPosition(5, 0);
                                break;
                            case "41":
                                ChangeKeyPosition(5, 1);
                                break;
                            case "42":
                                ChangeKeyPosition(5, 2);
                                break;
                            case "43":
                                ChangeKeyPosition(5, 3);
                                break;
                            case "44":
                                ChangeKeyPosition(5, 4);
                                break;
                            case "45":
                                ChangeKeyPosition(5, 5);
                                break;
                            case "46":
                                ChangeKeyPosition(5, 6);
                                break;
                            case "47":
                                ChangeKeyPosition(5, 7);
                                break;
                            case "48":
                                ChangeKeyPosition(6, 0);
                                break;
                            case "49":
                                ChangeKeyPosition(6, 1);
                                break;
                            case "50":
                                ChangeKeyPosition(6, 2);
                                break;
                            case "51":
                                ChangeKeyPosition(6, 3);
                                break;
                            case "52":
                                ChangeKeyPosition(6, 4);
                                break;
                            case "53":
                                ChangeKeyPosition(6, 5);
                                break;
                            case "54":
                                ChangeKeyPosition(6, 6);
                                break;
                            case "55":
                                ChangeKeyPosition(6, 7);
                                break;
                            case "56":
                                ChangeKeyPosition(7, 0);
                                break;
                            case "57":
                                ChangeKeyPosition(7, 1);
                                break;
                            case "58":
                                ChangeKeyPosition(7, 2);
                                break;
                            case "59":
                                ChangeKeyPosition(7, 3);
                                break;
                            case "60":
                                ChangeKeyPosition(7, 4);
                                break;
                            case "61":
                                ChangeKeyPosition(7, 5);
                                break;
                            case "62":
                                ChangeKeyPosition(7, 6);
                                break;
                            case "63":
                                ChangeKeyPosition(7, 7);
                                break;

                        }
                        Selected = false;
                        ChessBoardPlacementHandler.ClearHighlights();
                        ChessBoardPlacementHandler.change();
                    }


                }
            }

            //Update the pawn position when it gets the end of the row
            if (this.tag == "Pawn")
            {
                if (row == 7 || row == 0)
                    window.SetActive(true);
            }

        }

        //Change the chess pieces with power chess pieces
        public void ChangPawn(string name)
        {
            if ((row == 7 || row == 0) && this.tag == "Pawn")
            {
                this.name = name;
                this.tag = name;
                switch (name)
                {
                    case "Queen":
                        this.gameObject.GetComponent<SpriteRenderer>().sprite = newSprite[0];
                        break;
                    case "Rook":
                        this.gameObject.GetComponent<SpriteRenderer>().sprite = newSprite[1];
                        break;
                    case "Bishop":
                        this.gameObject.GetComponent<SpriteRenderer>().sprite = newSprite[2];
                        break;
                    case "Knight":
                        this.gameObject.GetComponent<SpriteRenderer>().sprite = newSprite[3];
                        break;
                }
            }
        }

        //change the position of chess pieces
        public void ChangeKeyPosition(int i, int j)
        {
            
            if (pawnFirstMove)
            {
                ChessBoardPlacementHandler.pawnFirstMove = false;
            }
            transform.position = ChessBoardPlacementHandler.Instance.GetTile(i, j).transform.position;
            row = i; column = j;
            ChessBoardPlacementHandler.KeyValue(row, column, true, white);
            
        }

        //Selecting the chess pieces 
        public void OnMouseUp()
        {
            
            if(ChessBoardPlacementHandler.BlackAndWhight(white))
            {
                Selected = true;
                ChessBoardPlacementHandler.ClearHighlights();

                //The condition that can move the chess pieces and show the possible moves 
                switch (this.tag)
                {
                    case "King":
                        for (int i = 0; i <= 7; i++)
                        {
                            for (int j = 0; j <= 7; j++)
                            {
                                if (i == row || j == column || i - j == row - column || i + j == row + column)
                                    if ((i != row || j != column) && (i == row + 1 || i == row - 1 || j == column + 1 || j == column - 1))
                                        if (!ChessBoardPlacementHandler.checkKeyValue(i, j))
                                            ChessBoardPlacementHandler.Highlight(i, j);
                                        else
                                        {
                                            if (white)
                                            {
                                                if (ChessBoardPlacementHandler.black[i * 8 + j])
                                                    ChessBoardPlacementHandler.AttackHighlight(i, j);
                                            }
                                            else
                                            {
                                                if (ChessBoardPlacementHandler.white[i * 8 + j])
                                                    ChessBoardPlacementHandler.AttackHighlight(i, j);
                                            }
                                        }
                            }
                        }
                        break;
                    case "Queen":

                        bool queen = true;
                        for (int i = row; i <= 7 && queen; i++)
                        {
                            for (int j = column; j <= 7 && queen; j++)
                            {
                                if (i - j == row - column || i + j == row + column)
                                    if (i != row || j != column)
                                        if (!ChessBoardPlacementHandler.checkKeyValue(i, j))
                                            ChessBoardPlacementHandler.Highlight(i, j);
                                        else
                                        {
                                            if (white)
                                            {
                                                if (ChessBoardPlacementHandler.black[i * 8 + j])
                                                    ChessBoardPlacementHandler.AttackHighlight(i, j);
                                            }
                                            else
                                            {
                                                if (ChessBoardPlacementHandler.white[i * 8 + j])
                                                    ChessBoardPlacementHandler.AttackHighlight(i, j);
                                            }
                                            queen = false;
                                        }

                            }
                        }
                        queen = true;
                        for (int i = row; i >= 0 && queen; i--)
                        {
                            for (int j = column; j >= 0 && queen; j--)
                            {
                                if (i - j == row - column || i + j == row + column)
                                    if (i != row || j != column)
                                        if (!ChessBoardPlacementHandler.checkKeyValue(i, j))
                                            ChessBoardPlacementHandler.Highlight(i, j);
                                        else
                                        {
                                            if (white)
                                            {
                                                if (ChessBoardPlacementHandler.black[i * 8 + j])
                                                    ChessBoardPlacementHandler.AttackHighlight(i, j);
                                            }
                                            else
                                            {
                                                if (ChessBoardPlacementHandler.white[i * 8 + j])
                                                    ChessBoardPlacementHandler.AttackHighlight(i, j);
                                            }
                                            queen = false;
                                        }

                            }
                        }
                        queen = true;
                        for (int i = row; i <= 7 && queen; i++)
                        {
                            for (int j = column; j >= 0 && queen; j--)
                            {
                                if (i - j == row - column || i + j == row + column)
                                    if (i != row || j != column)
                                        if (!ChessBoardPlacementHandler.checkKeyValue(i, j))
                                            ChessBoardPlacementHandler.Highlight(i, j);
                                        else
                                        {
                                            if (white)
                                            {
                                                if (ChessBoardPlacementHandler.black[i * 8 + j])
                                                    ChessBoardPlacementHandler.AttackHighlight(i, j);
                                            }
                                            else
                                            {
                                                if (ChessBoardPlacementHandler.white[i * 8 + j])
                                                    ChessBoardPlacementHandler.AttackHighlight(i, j);
                                            }
                                            queen = false;
                                        }

                            }
                        }
                        queen = true;
                        for (int i = row; i >= 0 && queen; i--)
                        {
                            for (int j = column; j <= 7 && queen; j++)
                            {
                                if (i - j == row - column || i + j == row + column)
                                    if (i != row || j != column)
                                        if (!ChessBoardPlacementHandler.checkKeyValue(i, j))
                                            ChessBoardPlacementHandler.Highlight(i, j);
                                        else
                                        {
                                            if (white)
                                            {
                                                if (ChessBoardPlacementHandler.black[i * 8 + j])
                                                    ChessBoardPlacementHandler.AttackHighlight(i, j);
                                            }
                                            else
                                            {
                                                if (ChessBoardPlacementHandler.white[i * 8 + j])
                                                    ChessBoardPlacementHandler.AttackHighlight(i, j);
                                            }
                                            queen = false;
                                        }

                            }
                        }
                        for (int j = column; j <= 7; j++)
                        {
                            int i = row;
                            if (i == row || j == column)
                                if (i + j != row + column)
                                    if (!ChessBoardPlacementHandler.checkKeyValue(i, j))
                                    {
                                        ChessBoardPlacementHandler.Highlight(i, j);

                                    }
                                    else
                                    {
                                        if (white)
                                        {
                                            if (ChessBoardPlacementHandler.black[i * 8 + j])
                                                ChessBoardPlacementHandler.AttackHighlight(i, j);
                                        }
                                        else
                                        {
                                            if (ChessBoardPlacementHandler.white[i * 8 + j])
                                                ChessBoardPlacementHandler.AttackHighlight(i, j);
                                        }
                                        break;
                                    }
                        }
                        for (int j = column; j >= 0; j--)
                        {
                            int i = row;
                            if (i == row || j == column)
                                if (i + j != row + column)
                                    if (!ChessBoardPlacementHandler.checkKeyValue(i, j))
                                    {
                                        ChessBoardPlacementHandler.Highlight(i, j);

                                    }
                                    else
                                    {
                                        if (white)
                                        {
                                            if (ChessBoardPlacementHandler.black[i * 8 + j])
                                                ChessBoardPlacementHandler.AttackHighlight(i, j);
                                        }
                                        else
                                        {
                                            if (ChessBoardPlacementHandler.white[i * 8 + j])
                                                ChessBoardPlacementHandler.AttackHighlight(i, j);
                                        }
                                        break;
                                    }
                        }
                        for (int i = row; i <= 7; i++)
                        {
                            int j = column;
                            if (i == row || j == column)
                                if (i + j != row + column)
                                    if (!ChessBoardPlacementHandler.checkKeyValue(i, j))
                                    {
                                        ChessBoardPlacementHandler.Highlight(i, j);

                                    }
                                    else
                                    {
                                        if (white)
                                        {
                                            if (ChessBoardPlacementHandler.black[i * 8 + j])
                                                ChessBoardPlacementHandler.AttackHighlight(i, j);
                                        }
                                        else
                                        {
                                            if (ChessBoardPlacementHandler.white[i * 8 + j])
                                                ChessBoardPlacementHandler.AttackHighlight(i, j);
                                        }
                                        break;
                                    }
                        }
                        for (int i = row; i >= 0; i--)
                        {
                            int j = column;
                            if (i == row || j == column)
                                if (i + j != row + column)
                                    if (!ChessBoardPlacementHandler.checkKeyValue(i, j))
                                    {
                                        ChessBoardPlacementHandler.Highlight(i, j);

                                    }
                                    else
                                    {
                                        if (white)
                                        {
                                            if (ChessBoardPlacementHandler.black[i * 8 + j])
                                                ChessBoardPlacementHandler.AttackHighlight(i, j);
                                        }
                                        else
                                        {
                                            if (ChessBoardPlacementHandler.white[i * 8 + j])
                                                ChessBoardPlacementHandler.AttackHighlight(i, j);
                                        }
                                        break;
                                    }
                        }
                        break;
                    case "Bishop":
                        bool bishop = true;
                        for (int i = row; i <= 7 && bishop; i++)
                        {
                            for (int j = column; j <= 7 && bishop; j++)
                            {
                                if (i - j == row - column || i + j == row + column)
                                    if (i != row || j != column)
                                        if (!ChessBoardPlacementHandler.checkKeyValue(i, j))
                                            ChessBoardPlacementHandler.Highlight(i, j);
                                        else
                                        {
                                            if (white)
                                            {
                                                if (ChessBoardPlacementHandler.black[i * 8 + j])
                                                    ChessBoardPlacementHandler.AttackHighlight(i, j);
                                            }
                                            else
                                            {
                                                if (ChessBoardPlacementHandler.white[i * 8 + j])
                                                    ChessBoardPlacementHandler.AttackHighlight(i, j);
                                            }
                                            bishop = false;
                                        }

                            }
                        }
                        bishop = true;
                        for (int i = row; i >= 0 && bishop; i--)
                        {
                            for (int j = column; j >= 0 && bishop; j--)
                            {
                                if (i - j == row - column || i + j == row + column)
                                    if (i != row || j != column)
                                        if (!ChessBoardPlacementHandler.checkKeyValue(i, j))
                                            ChessBoardPlacementHandler.Highlight(i, j);
                                        else
                                        {
                                            if (white)
                                            {
                                                if (ChessBoardPlacementHandler.black[i * 8 + j])
                                                    ChessBoardPlacementHandler.AttackHighlight(i, j);
                                            }
                                            else
                                            {
                                                if (ChessBoardPlacementHandler.white[i * 8 + j])
                                                    ChessBoardPlacementHandler.AttackHighlight(i, j);
                                            }
                                            bishop = false;
                                        }

                            }
                        }
                        bishop = true;
                        for (int i = row; i >= 0 && bishop; i--)
                        {
                            for (int j = column; j <= 7 && bishop; j++)
                            {
                                if (i - j == row - column || i + j == row + column)
                                    if (i != row || j != column)
                                        if (!ChessBoardPlacementHandler.checkKeyValue(i, j))
                                            ChessBoardPlacementHandler.Highlight(i, j);
                                        else
                                        {
                                            if (white)
                                            {
                                                if (ChessBoardPlacementHandler.black[i * 8 + j])
                                                    ChessBoardPlacementHandler.AttackHighlight(i, j);
                                            }
                                            else
                                            {
                                                if (ChessBoardPlacementHandler.white[i * 8 + j])
                                                    ChessBoardPlacementHandler.AttackHighlight(i, j);
                                            }
                                            bishop = false;
                                        }

                            }
                        }
                        bishop = true;
                        for (int i = row; i <= 7 && bishop; i++)
                        {
                            for (int j = column; j >= 0 && bishop; j--)
                            {
                                if (i - j == row - column || i + j == row + column)
                                    if (i != row || j != column)
                                        if (!ChessBoardPlacementHandler.checkKeyValue(i, j))
                                            ChessBoardPlacementHandler.Highlight(i, j);
                                        else
                                        {
                                            if (white)
                                            {
                                                if (ChessBoardPlacementHandler.black[i * 8 + j])
                                                    ChessBoardPlacementHandler.AttackHighlight(i, j);
                                            }
                                            else
                                            {
                                                if (ChessBoardPlacementHandler.white[i * 8 + j])
                                                    ChessBoardPlacementHandler.AttackHighlight(i, j);
                                            }
                                            bishop = false;
                                        }

                            }
                        }

                        break;
                    case "Knight":
                        for (int i = 0; i <= 7; i++)
                        {
                            for (int j = 0; j <= 7; j++)
                            {
                                if ((i == row + 1 && (j == column - 2 || j == column + 2)) || (i == row + 2 && (j == column - 1 || j == column + 1)) || (i == row - 1 && (j == column + 2 || j == column - 2)) || (i == row - 2 && (j == column + 1 || j == column - 1)))
                                    if (i + j != row + column)
                                    {

                                        if (!ChessBoardPlacementHandler.checkKeyValue(i, j))
                                            ChessBoardPlacementHandler.Highlight(i, j);
                                        else
                                        {
                                            if (white)
                                            {
                                                if (ChessBoardPlacementHandler.black[i * 8 + j])
                                                    ChessBoardPlacementHandler.AttackHighlight(i, j);
                                            }
                                            else
                                            {
                                                if (ChessBoardPlacementHandler.white[i * 8 + j])
                                                    ChessBoardPlacementHandler.AttackHighlight(i, j);
                                            }
                                        }
                                    }

                            }
                        }
                        break;
                    case "Rook":
                        for (int j = column; j <= 7; j++)
                        {
                            int i = row;
                            if (i == row || j == column)
                                if (i + j != row + column)
                                    if (!ChessBoardPlacementHandler.checkKeyValue(i, j))
                                    {
                                        ChessBoardPlacementHandler.Highlight(i, j);

                                    }
                                    else
                                    {
                                        if (white)
                                        {
                                            if (ChessBoardPlacementHandler.black[i * 8 + j])
                                                ChessBoardPlacementHandler.AttackHighlight(i, j);
                                        }
                                        else
                                        {
                                            if (ChessBoardPlacementHandler.white[i * 8 + j])
                                                ChessBoardPlacementHandler.AttackHighlight(i, j);
                                        }
                                        break;
                                    }
                        }

                        for (int j = column; j >= 0; j--)
                        {
                            int i = row;
                            if (i == row || j == column)
                                if (i + j != row + column)
                                    if (!ChessBoardPlacementHandler.checkKeyValue(i, j))
                                    {
                                        ChessBoardPlacementHandler.Highlight(i, j);

                                    }
                                    else
                                    {
                                        if (white)
                                        {
                                            if (ChessBoardPlacementHandler.black[i * 8 + j])
                                                ChessBoardPlacementHandler.AttackHighlight(i, j);
                                        }
                                        else
                                        {
                                            if (ChessBoardPlacementHandler.white[i * 8 + j])
                                                ChessBoardPlacementHandler.AttackHighlight(i, j);
                                        }
                                        break;
                                    }
                        }

                        for (int i = row; i <= 7; i++)
                        {
                            int j = column;
                            if (i == row || j == column)
                                if (i + j != row + column)
                                    if (!ChessBoardPlacementHandler.checkKeyValue(i, j))
                                    {
                                        ChessBoardPlacementHandler.Highlight(i, j);

                                    }
                                    else
                                    {
                                        if (white)
                                        {
                                            if (ChessBoardPlacementHandler.black[i * 8 + j])
                                                ChessBoardPlacementHandler.AttackHighlight(i, j);
                                        }
                                        else
                                        {
                                            if (ChessBoardPlacementHandler.white[i * 8 + j])
                                                ChessBoardPlacementHandler.AttackHighlight(i, j);
                                        }
                                        break;
                                    }
                        }

                        for (int i = row; i >= 0; i--)
                        {
                            int j = column;
                            if (i == row || j == column)
                                if (i + j != row + column)
                                    if (!ChessBoardPlacementHandler.checkKeyValue(i, j))
                                    {
                                        ChessBoardPlacementHandler.Highlight(i, j);

                                    }
                                    else
                                    {
                                        if (white)
                                        {
                                            if (ChessBoardPlacementHandler.black[i * 8 + j])
                                                ChessBoardPlacementHandler.AttackHighlight(i, j);
                                        }
                                        else
                                        {
                                            if (ChessBoardPlacementHandler.white[i * 8 + j])
                                                ChessBoardPlacementHandler.AttackHighlight(i, j);
                                        }
                                        break;
                                    }
                        }
                        break;
                    case "Pawn":
                        pawnFirstMove = ChessBoardPlacementHandler.pawnFirstMove;

                        if (white)
                        {
                            if (pawnFirstMove)
                            {
                                for (int i = row; i >= row - 2; i--)
                                {
                                    int j = column;
                                    if (i == row || j == column)
                                        if (i + j != row + column)
                                            if (!ChessBoardPlacementHandler.checkKeyValue(i, j))
                                            {
                                                ChessBoardPlacementHandler.Highlight(i, j);

                                            }
                                            else
                                            {
                                                break;
                                            }
                                }
                            }
                            else
                            {
                                if (column <= 7 && row < 7)
                                {
                                    if (ChessBoardPlacementHandler.black[(row - 1) * 8 + column] || ChessBoardPlacementHandler.black[(row - 1) * 8 + (column + 1)] || ChessBoardPlacementHandler.black[(row - 1) * 8 + (column - 1)])
                                    {
                                        if (column < 7)
                                            if (ChessBoardPlacementHandler.checkKeyValue(row - 1, column + 1))
                                                ChessBoardPlacementHandler.AttackHighlight(row - 1, column + 1);
                                        if (column > 0)
                                            if (ChessBoardPlacementHandler.checkKeyValue(row - 1, column - 1))
                                                ChessBoardPlacementHandler.AttackHighlight(row - 1, column - 1);
                                        if (row < 7)
                                            if (!ChessBoardPlacementHandler.checkKeyValue(row - 1, column))
                                                ChessBoardPlacementHandler.Highlight(row - 1, column);
                                    }
                                    else
                                    {
                                        ChessBoardPlacementHandler.Highlight(row - 1, column);
                                    }

                                }

                            }
                        }
                        else
                        {
                            if (pawnFirstMove)
                            {
                                for (int i = row; i <= row + 2; i++)
                                {
                                    int j = column;
                                    if (i == row || j == column)
                                        if (i + j != row + column)
                                            if (!ChessBoardPlacementHandler.checkKeyValue(i, j))
                                            {
                                                ChessBoardPlacementHandler.Highlight(i, j);

                                            }
                                            else
                                            {
                                                break;
                                            }
                                }
                            }
                            else
                            {
                                if (column <= 7 && row < 7)
                                {
                                    if (ChessBoardPlacementHandler.white[(row + 1) * 8 + column] || ChessBoardPlacementHandler.white[(row + 1) * 8 + (column + 1)] || ChessBoardPlacementHandler.white[(row + 1) * 8 + (column - 1)])
                                    {
                                        if (column < 7)
                                            if (ChessBoardPlacementHandler.checkKeyValue(row + 1, column + 1))
                                                ChessBoardPlacementHandler.AttackHighlight(row + 1, column + 1);
                                        if (column > 0)
                                            if (ChessBoardPlacementHandler.checkKeyValue(row + 1, column - 1))
                                                ChessBoardPlacementHandler.AttackHighlight(row + 1, column - 1);
                                        if (!ChessBoardPlacementHandler.checkKeyValue(row + 1, column))
                                            ChessBoardPlacementHandler.Highlight(row + 1, column);
                                    }
                                    else
                                    {
                                        ChessBoardPlacementHandler.Highlight(row + 1, column);
                                    }
                                }

                            }

                        }

                        break;
                }
            }


        }


    }

}